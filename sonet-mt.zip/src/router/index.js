import Vue from "vue";
import VueRouter from "vue-router";
import routeMap from "@/router/routes";

Vue.use(VueRouter);

const routes = [
  {
    path: "",
    redirect: "/Login"
  },
  // 404
  {
    path: "/404",
    component: routeMap["404"]
  },
  {
    path: "*",
    redirect: "/404"
  },
  // 404
  // 移动端
  {
    path: "/Home",
    name: "Home",
    component: routeMap["Home"]
  },
  {
    path: "/Login",
    name: "Login",
    component: routeMap["Login"]
  },
  {
    path: "/Registered",
    name: "Registered",
    component: routeMap["Registered"]
  },
  {
    path: "/ForgetPassword",
    name: "ForgetPassword",
    component: routeMap["ForgetPassword"]
  },
  {
    path: "/InterestedContent",
    name: "InterestedContent",
    component: routeMap["InterestedContent"]
  },
  {
    path: "/UseTeaching",
    name: "UseTeaching",
    component: routeMap["UseTeaching"]
  }
];

const router = new VueRouter({
  routes
});

export default router;
