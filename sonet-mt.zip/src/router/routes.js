const routes = {
  // 404
  404: () =>
    import(
      /* webpackChunkName: '404' */
      "@/views/404/404.vue"
    ),
  // 404
  // Login
  // 登录
  Login: () =>
    import(
      /* webpackChunkName: "Login" */
      "@/views/Login/Login.vue"
    ),
  // 注册
  Registered: () =>
    import(
      /* webpackChunkName: "Registered" */
      "@/views/Login/Registered.vue"
    ),
  // 忘记密码
  ForgetPassword: () =>
    import(
      /* webpackChunkName: "ForgetPassword" */
      "@/views/Login/ForgetPassword.vue"
    ),
  // Login
  // 首页
  Home: () =>
    import(
      /* webpackChunkName: "Home" */
      "@/views/Home/Home.vue"
    ),
  // 感兴趣的内容
  // 感兴趣的内容
  InterestedContent: () =>
    import(
      /* webpackChunkName: "InterestedContent" */
      "@/views/InterestedContent/InterestedContent.vue"
    ),
  // 使用教学
  UseTeaching: () =>
    import(
      /* webpackChunkName: "UseTeaching" */
      "@/views/InterestedContent/UseTeaching.vue"
    )
};

export default routes;
