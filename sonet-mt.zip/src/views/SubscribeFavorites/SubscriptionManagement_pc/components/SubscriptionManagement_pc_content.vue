<template>
  <div class="SubscriptionManagement_pc_content">
    <div class="SubscriptionManagement_pc_contents">
      <HeaderMenuPc />
      <div class="SubscriptionManagement_pc_content_box">
        <h1>訂閱管理</h1>
        <div class="SubscriptionManagement_pc_content_box_div">
          <div class="SubscriptionManagement_pc_content_box_div_null" v-if="!dataList || dataList.length == 0">
            <img src="@/assets/img_pc/icon_notice.png" alt="" />
            <p>尚無任何訂閲</p>
          </div>
          <div
            class="SubscriptionManagement_pc_content_box_div_content"
            v-for="(item, index) in dataList"
            :key="index"
          >
            <em></em>
            <img :src="item.imgUrl" alt="" />
            <div>
              <h3>{{ item.name }}</h3>
              <p>FC粉絲團成員（{{ item.num }}人）</p>
              <p>自動續訂日期：{{ item.time }}</p>
              <button>變更</button>
            </div>
          </div>
          <!-- 分頁 -->
          <PaginationPc
            :currentpage="offset"
            :pagesize="limit"
            :total="total"
            :handleCurrentChange="handleCurrentChange"
          ></PaginationPc>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeaderMenuPc from "@/components_pc/HeaderMenu_pc";
import PaginationPc from "@/components_pc/Pagination_pc";
import { GET_GetSubscribeList } from "@/api/api";
export default {
  name: "SubscriptionManagement_pc_content",
  components: {
    HeaderMenuPc,
    PaginationPc
  },
  data() {
    return {
      offset: 1,
      limit: 10,
      total: 0,
      dataList: [
        {
          imgUrl: require("@/assets/img_pc/RightMenu2.png"),
          name: "木村拓哉",
          num: "365",
          time: "2020-11-31"
        },
        {
          imgUrl: require("@/assets/img_pc/RightMenu2.png"),
          name: "木村拓哉1",
          num: "663",
          time: "2020-11-31"
        },
        {
          imgUrl: require("@/assets/img_pc/RightMenu2.png"),
          name: "木村拓哉2",
          num: "1265",
          time: "2020-11-31"
        },
        {
          imgUrl: require("@/assets/img_pc/RightMenu2.png"),
          name: "木村拓哉2",
          num: "1265",
          time: "2020-11-31"
        }
      ]
    };
  },
  created() {
    this._getSubscribeList();
  },
  methods: {
    // 分页切换
    handleCurrentChange(val) {
      this.offset = val;
      this._getSubscribeList();
    },
    // 获取订阅管理
    _getSubscribeList() {
      let form = {
        page: this.offset,
        per_page: this.limit
      };
      GET_GetSubscribeList(form).then(res => {
        if (res.code == 200) {
          // this.dataList = res.data.list;
          this.total = res.data.pagination.total;
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.SubscriptionManagement_pc_content {
  width: 766px;
  height: 1018px;
  position: relative;
  overflow: hidden;
  .SubscriptionManagement_pc_contents {
    position: absolute;
    left: 0;
    top: 0;
    right: -17px;
    bottom: 0;
    overflow-x: hidden;
    overflow-y: scroll;
    .SubscriptionManagement_pc_content_box {
      margin-top: 10px;
      width: 100%;
      min-height: 875px;
      background: #fff;
      h1 {
        height: 63px;
        padding-left: 90px;
        border-bottom: 1px solid #f6f7f8;
        font-size: 20px;
        font-weight: bold;
        color: #000000;
        line-height: 63px;
      }
      .SubscriptionManagement_pc_content_box_div {
        width: 100%;
        padding: 30px 0 30px 90px;
        display: flex;
        flex-wrap: wrap;
        .SubscriptionManagement_pc_content_box_div_null {
          // margin: 110px auto 0;
          width: 100%;
          padding-right: 90px;
          padding-top: 110px;
          text-align: center;
          p {
            margin-top: 27px;
            font-size: 16px;
            font-weight: 400;
            color: #9BA1A9;
            line-height: 24px;
          }
        }
        .SubscriptionManagement_pc_content_box_div_content:hover {
          em {
            display: block;
          }
        }
        .SubscriptionManagement_pc_content_box_div_content {
          cursor: pointer;
          display: flex;
          padding: 16px 16px 12px 16px;
          margin: 0 18px 18px 0;
          width: 310px;
          background: #ffffff;
          box-shadow: 0px 14px 120px -18px rgba(0, 0, 0, 0.1);
          border-radius: 6px;
          position: relative;
          em {
            display: none;
            pointer-events: none;
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            right: 0;
            width: 100%;
            height: 100%;
            background: rgba(88, 88, 88, 0.1);
            border-radius: 6px;
          }
          img {
            width: 62px;
            height: 62px;
            margin-right: 17px;
          }
          div {
            width: calc(100% - 79px);
            h3 {
              font-size: 14px;
              font-weight: bold;
              color: #585858;
              line-height: 20px;
            }
            p {
              margin: 5px 0;
              font-size: 14px;
              font-weight: 400;
              color: #9ba1a9;
              line-height: 24px;
            }
            button {
              float: right;
              width: 84px;
              height: 30px;
              background: #1db3ce;
              border-radius: 15px;
              font-size: 14px;
              font-weight: 400;
              color: #ffffff;
              line-height: 20px;
            }
          }
        }
      }
    }
  }
}
</style>
