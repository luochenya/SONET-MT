<template>
  <div class="SubscriptionManagement_pc">
    <HeaderPc />
    <div class="SubscriptionManagement_pc_box response">
      <LeftMenuPc />
      <SubscriptionManagement_pc_Content />
      <RightMenuPc />
    </div>
  </div>
</template>

<script>
import HeaderPc from "@/components_pc/Header_pc";
import LeftMenuPc from "@/components_pc/LeftMenu_pc";
import RightMenuPc from "@/components_pc/RightMenu_pc";
import SubscriptionManagement_pc_Content from "./components/SubscriptionManagement_pc_content";
export default {
  name: "SubscriptionManagement_pc",
  components: {
    HeaderPc,
    LeftMenuPc,
    RightMenuPc,
    SubscriptionManagement_pc_Content
  }
}
</script>

<style lang="scss" scoped>
.SubscriptionManagement_pc {
  padding-top: 94px;
  padding-bottom: 14px;
  width: 100%;
  min-height: 100vh;
  background: #f6f7f8;
  .SubscriptionManagement_pc_box {
    display: flex;
    justify-content: space-between;
  }
}
</style>
